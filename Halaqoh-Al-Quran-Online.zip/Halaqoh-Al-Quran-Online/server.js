
const express=require('express');
const Database=require('better-sqlite3');
const crypto=require('crypto');
const cookieParser=require('cookie-parser');
const path=require('path');
const app=express();
const db=new Database(process.env.DB_FILE||'./data/halaqoh.db');
db.pragma('journal_mode=WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS halaqoh(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,ustadz_id INTEGER REFERENCES users(id) ON DELETE SET NULL);
CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,halaqoh_id INTEGER REFERENCES halaqoh(id) ON DELETE SET NULL);
CREATE TABLE IF NOT EXISTS records(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,ustadz_id INTEGER NOT NULL REFERENCES users(id),type TEXT NOT NULL,surah TEXT NOT NULL,ayat TEXT NOT NULL,note TEXT,record_date TEXT NOT NULL,created_at TEXT NOT NULL);
`);
const hash=p=>crypto.createHash('sha256').update(String(p)).digest('hex');
const now=()=>new Date().toISOString();
if(!db.prepare("SELECT 1 FROM users WHERE username='admin'").get())
 db.prepare("INSERT INTO users(name,username,password_hash,role) VALUES(?,?,?,?)").run('Administrator','admin',hash('admin123'),'admin');
app.use(express.json());app.use(cookieParser());app.use(express.static(path.join(__dirname,'public')));
const sessions=new Map();
function auth(req,res,next){const u=sessions.get(req.cookies.halaqoh);if(!u)return res.status(401).json({error:'Belum login'});req.user=u;next()}
function admin(req,res,next){if(req.user.role!=='admin')return res.status(403).json({error:'Khusus Admin'});next()}
app.post('/api/login',(req,res)=>{const u=db.prepare('SELECT * FROM users WHERE username=?').get(String(req.body.username||'').trim().toLowerCase());if(!u||!u.active||u.password_hash!==hash(req.body.password||''))return res.status(401).json({error:'Username atau password salah'});const sid=crypto.randomBytes(24).toString('hex');const user={id:u.id,name:u.name,username:u.username,role:u.role};sessions.set(sid,user);res.cookie('halaqoh',sid,{httpOnly:true,sameSite:'lax'}).json({user})});
app.post('/api/logout',auth,(req,res)=>{sessions.delete(req.cookies.halaqoh);res.clearCookie('halaqoh').json({ok:true})});
app.get('/api/me',auth,(req,res)=>res.json(req.user));
app.get('/api/users',auth,admin,(req,res)=>res.json(db.prepare("SELECT id,name,username,active FROM users WHERE role='ustadz' ORDER BY name").all()));
app.post('/api/users',auth,admin,(req,res)=>{try{const r=db.prepare("INSERT INTO users(name,username,password_hash,role) VALUES(?,?,?,'ustadz')").run(req.body.name,String(req.body.username).toLowerCase(),hash(req.body.password));res.json({id:r.lastInsertRowid})}catch(e){res.status(400).json({error:'Username sudah digunakan'})}});
app.patch('/api/users/:id',auth,admin,(req,res)=>{db.prepare("UPDATE users SET active=? WHERE id=? AND role='ustadz'").run(req.body.active?1:0,req.params.id);res.json({ok:true})});
app.get('/api/halaqoh',auth,(req,res)=>{const q=req.user.role==='admin'?"SELECT h.*,u.name ustadz_name FROM halaqoh h LEFT JOIN users u ON u.id=h.ustadz_id ORDER BY h.id DESC":"SELECT h.*,u.name ustadz_name FROM halaqoh h LEFT JOIN users u ON u.id=h.ustadz_id WHERE h.ustadz_id=?";res.json(req.user.role==='admin'?db.prepare(q).all():db.prepare(q).all(req.user.id))});
app.post('/api/halaqoh',auth,admin,(req,res)=>{const r=db.prepare('INSERT INTO halaqoh(name,ustadz_id) VALUES(?,?)').run(req.body.name,req.body.ustadz_id||null);res.json({id:r.lastInsertRowid})});
app.get('/api/students',auth,(req,res)=>{if(req.user.role==='admin')return res.json(db.prepare("SELECT s.*,h.name halaqoh_name,u.name ustadz_name FROM students s LEFT JOIN halaqoh h ON h.id=s.halaqoh_id LEFT JOIN users u ON u.id=h.ustadz_id WHERE s.active=1 ORDER BY s.name").all());res.json(db.prepare("SELECT s.*,h.name halaqoh_name FROM students s JOIN halaqoh h ON h.id=s.halaqoh_id WHERE h.ustadz_id=? AND s.active=1 ORDER BY s.name").all(req.user.id))});
app.post('/api/students',auth,admin,(req,res)=>{const r=db.prepare('INSERT INTO students(name,halaqoh_id) VALUES(?,?)').run(req.body.name,req.body.halaqoh_id||null);res.json({id:r.lastInsertRowid})});
app.patch('/api/students/:id',auth,admin,(req,res)=>{db.prepare('UPDATE students SET halaqoh_id=? WHERE id=?').run(req.body.halaqoh_id||null,req.params.id);res.json({ok:true})});
app.delete('/api/students/:id',auth,admin,(req,res)=>{db.prepare('UPDATE students SET active=0 WHERE id=?').run(req.params.id);res.json({ok:true})});
app.post('/api/records',auth,(req,res)=>{const s=db.prepare("SELECT s.id,h.ustadz_id FROM students s LEFT JOIN halaqoh h ON h.id=s.halaqoh_id WHERE s.id=? AND s.active=1").get(req.body.student_id);if(!s||(req.user.role!=='admin'&&s.ustadz_id!==req.user.id))return res.status(403).json({error:'Santri bukan bagian halaqoh Anda'});const r=db.prepare("INSERT INTO records(student_id,ustadz_id,type,surah,ayat,note,record_date,created_at) VALUES(?,?,?,?,?,?,?,?)").run(s.id,req.user.id,req.body.type,req.body.surah,req.body.ayat,req.body.note||'',req.body.record_date||new Date().toISOString().slice(0,10),now());res.json({id:r.lastInsertRowid})});
function dates(period,d){const x=new Date((d||new Date().toISOString().slice(0,10))+'T00:00:00');let a,b;if(period==='weekly'){let n=(x.getDay()+6)%7;a=new Date(x);a.setDate(x.getDate()-n);b=new Date(a);b.setDate(a.getDate()+6)}else if(period==='semester'){let y=x.getFullYear();a=x.getMonth()<6?new Date(y,0,1):new Date(y,6,1);b=x.getMonth()<6?new Date(y,5,30):new Date(y,11,31)}else{a=new Date(x.getFullYear(),x.getMonth(),1);b=new Date(x.getFullYear(),x.getMonth()+1,0)}return [a.toISOString().slice(0,10),b.toISOString().slice(0,10)]}
app.get('/api/recap',auth,(req,res)=>{const [a,b]=dates(req.query.period||'monthly',req.query.date);let q="SELECT s.name,COUNT(CASE WHEN r.type='hafalan' THEN 1 END) hafalan,COUNT(CASE WHEN r.type='murajaah' THEN 1 END) murajaah FROM students s LEFT JOIN records r ON r.student_id=s.id AND r.record_date BETWEEN ? AND ? LEFT JOIN halaqoh h ON h.id=s.halaqoh_id WHERE s.active=1";const p=[a,b];if(req.user.role==='ustadz'){q+=' AND h.ustadz_id=?';p.push(req.user.id)}q+=' GROUP BY s.id ORDER BY s.name';res.json({start:a,end:b,rows:db.prepare(q).all(...p)})});
app.get('/api/records',auth,(req,res)=>{let q="SELECT r.*,s.name student_name FROM records r JOIN students s ON s.id=r.student_id LEFT JOIN halaqoh h ON h.id=s.halaqoh_id WHERE 1=1",p=[];if(req.user.role==='ustadz'){q+=' AND r.ustadz_id=?';p.push(req.user.id)}q+=' ORDER BY r.record_date DESC,r.id DESC';res.json(db.prepare(q).all(...p))});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(process.env.PORT||3000,()=>console.log('Halaqoh online ready'));
