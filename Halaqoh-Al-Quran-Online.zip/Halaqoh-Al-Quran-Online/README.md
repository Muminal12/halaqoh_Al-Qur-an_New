# Aplikasi Halaqoh Al Qur'an Online

## Login awal
Admin: `admin` / `admin123`

## Jalankan
- Node.js 20/22
- `npm install`
- `npm start`
- buka `http://localhost:3000`

## Catatan
Versi ini sudah memakai database terpusat SQLite + backend Express. Untuk produksi multi-device, deploy ke VPS/cloud dan gunakan PostgreSQL managed (mis. Supabase/Neon) serta session store persisten.
